// src/components/admin/AdminApp.jsx
// ============================================================
// Full admin dashboard — all tabs wired to live Supabase data.
// ============================================================

import { useState, useEffect, useRef } from "react";
import { C } from '../../constants/colors';
import { supabase } from '../../lib/supabase';
import CurriculumUploader from './CurriculumUploader';
import Btn from '../ui/Btn';
import Pill from '../ui/Pill';

const NAV = [
  { id: "overview",   icon: "📊", label: "Overview"   },
  { id: "curriculum", icon: "📚", label: "Curriculum"  },
  { id: "content",    icon: "📝", label: "Content"     },
  { id: "textbooks",  icon: "📄", label: "Textbooks"   },
  { id: "users",      icon: "👥", label: "Users"       },
  { id: "flagged",    icon: "🚩", label: "Flagged Qs"  },
];

export default function AdminApp({ onExitAdmin }) {
  const [tab, setTab] = useState("overview");

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#F5F2EC" }}>
      <div style={{
        width: 220, background: C.navy, display: "flex", flexDirection: "column",
        padding: "28px 0 20px", flexShrink: 0, position: "sticky", top: 0, height: "100vh",
      }}>
        <div style={{ padding: "0 20px 24px", borderBottom: "1px solid rgba(255,255,255,0.12)" }}>
          <div style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 20, color: "#fff" }}>🧮 Admin</div>
          <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", fontWeight: 600, marginTop: 2 }}>MathsInBites CMS</div>
        </div>
        <nav style={{ flex: 1, padding: "16px 12px" }}>
          {NAV.map(({ id, icon, label }) => (
            <div key={id} onClick={() => setTab(id)} style={{
              display: "flex", alignItems: "center", gap: 10,
              padding: "10px 12px", borderRadius: 12, marginBottom: 4, cursor: "pointer",
              background: tab === id ? "rgba(255,255,255,0.12)" : "transparent",
              color: tab === id ? "#fff" : "rgba(255,255,255,0.55)",
              fontWeight: 700, fontSize: 14, transition: "all 0.18s",
            }}>
              <span style={{ fontSize: 18 }}>{icon}</span>{label}
            </div>
          ))}
        </nav>
        <div style={{ padding: "0 12px" }}>
          <div onClick={onExitAdmin} style={{
            display: "flex", alignItems: "center", gap: 10,
            padding: "10px 12px", borderRadius: 12, cursor: "pointer",
            color: "rgba(255,255,255,0.45)", fontWeight: 700, fontSize: 14,
          }}>
            ← Exit Admin
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: "auto", minHeight: "100vh" }}>
        {tab === "overview"   && <AdminOverview />}
        {tab === "curriculum" && <CurriculumUploader />}
        {tab === "content"    && <AdminContent />}
        {tab === "textbooks"  && <AdminTextbooks />}
        {tab === "users"      && <AdminUsers />}
        {tab === "flagged"    && <AdminFlaggedQuestions />}
      </div>
    </div>
  );
}

// ── Overview ──────────────────────────────────────────────────
function AdminOverview() {
  const [stats, setStats] = useState(null);

  useEffect(() => {
    Promise.all([
      supabase.from('learning_paths').select('id', { count: 'exact', head: true }).eq('is_active', true),
      supabase.from('topics').select('id', { count: 'exact', head: true }).eq('is_active', true),
      supabase.from('lessons').select('id', { count: 'exact', head: true }),
      supabase.from('user_profiles').select('id', { count: 'exact', head: true }),
    ]).then(([paths, topics, lessons, students]) => {
      setStats({ paths: paths.count||0, topics: topics.count||0, lessons: lessons.count||0, students: students.count||0 });
    });
  }, []);

  return (
    <div style={{ padding: 32 }}>
      <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>Overview</h1>
      <p style={{ color: C.muted, fontWeight: 600, marginBottom: 28 }}>Your platform at a glance</p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16, marginBottom: 28 }}>
        {[
          { label: "Learning Paths",    key: "paths",    icon: "📚", color: C.fire   },
          { label: "Topics",            key: "topics",   icon: "🔢", color: C.purple },
          { label: "Lessons Generated", key: "lessons",  icon: "✅", color: C.mint   },
          { label: "Students",          key: "students", icon: "👥", color: C.sky    },
        ].map(({ label, key, icon, color }) => (
          <div key={label} className="card" style={{ padding: 22 }}>
            <div style={{ fontSize: 28, marginBottom: 8 }}>{icon}</div>
            <div style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 30, color }}>
              {stats ? stats[key] : "—"}
            </div>
            <div style={{ fontSize: 12, color: C.muted, fontWeight: 700 }}>{label}</div>
          </div>
        ))}
      </div>
      <div className="card" style={{ padding: 24 }}>
        <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 18, color: C.navy, marginBottom: 12 }}>Getting Started</div>
        {[
          ["1", "Upload curriculum", "Go to Curriculum → select a class → paste your curriculum text", C.fire],
          ["2", "Students open lessons", "AI generates topics & lessons automatically when students open subtopics", C.purple],
          ["3", "Review flagged questions", "Check Flagged Qs → review questions students reported as incorrect", C.mint],
        ].map(([num, title, desc, color]) => (
          <div key={num} style={{ display: "flex", gap: 14, marginBottom: 16, alignItems: "flex-start" }}>
            <div style={{ width: 32, height: 32, borderRadius: 10, background: `${color}22`, border: `2px solid ${color}44`, display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 900, fontSize: 14, color, flexShrink: 0 }}>{num}</div>
            <div>
              <div style={{ fontWeight: 800, fontSize: 15, color: C.navy }}>{title}</div>
              <div style={{ fontSize: 13, color: C.muted, fontWeight: 600, marginTop: 2 }}>{desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Content ───────────────────────────────────────────────────
function AdminContent() {
  const [lessons, setLessons] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    supabase
      .from('lessons')
      .select('id, title, is_approved, created_at, subtopics(name, topics(name))')
      .order('created_at', { ascending: false })
      .limit(60)
      .then(({ data }) => { setLessons(data || []); setLoading(false); });
  }, []);

  const toggleApprove = async (id, current) => {
    await supabase.from('lessons').update({ is_approved: !current }).eq('id', id);
    setLessons(ls => ls.map(l => l.id === id ? { ...l, is_approved: !current } : l));
  };

  const filtered = filter === "all" ? lessons
    : filter === "pending" ? lessons.filter(l => !l.is_approved)
    : lessons.filter(l => l.is_approved);

  return (
    <div style={{ padding: 32 }}>
      <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>Content</h1>
      <p style={{ color: C.muted, fontWeight: 600, marginBottom: 20 }}>Review and approve AI-generated lessons.</p>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["all","All"],["pending","Pending"],["approved","Approved"]].map(([id, label]) => (
          <div key={id} onClick={() => setFilter(id)} style={{
            padding: "7px 18px", borderRadius: 50, cursor: "pointer", fontWeight: 800, fontSize: 13,
            border: `2px solid ${filter === id ? C.fire : C.border}`,
            background: filter === id ? `${C.fire}12` : "#fff",
            color: filter === id ? C.fire : C.muted,
          }}>{label}</div>
        ))}
      </div>
      {loading ? (
        [1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 72, borderRadius: 16, marginBottom: 10 }} />)
      ) : filtered.length === 0 ? (
        <div className="card" style={{ padding: 40, textAlign: "center", color: C.muted }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>📝</div>
          <div style={{ fontWeight: 700 }}>No lessons yet — they appear when students open subtopics</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {filtered.map(lesson => (
            <div key={lesson.id} className="card" style={{ padding: "16px 20px", display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: 15, color: C.navy, marginBottom: 2 }}>{lesson.title || "Untitled Lesson"}</div>
                <div style={{ fontSize: 12, color: C.muted, fontWeight: 600 }}>
                  {lesson.subtopics?.topics?.name && `${lesson.subtopics.topics.name} → `}
                  {lesson.subtopics?.name} · {new Date(lesson.created_at).toLocaleDateString()}
                </div>
              </div>
              <Pill color={lesson.is_approved ? C.mint : C.sun}>{lesson.is_approved ? "Approved" : "Pending"}</Pill>
              <Btn onClick={() => toggleApprove(lesson.id, lesson.is_approved)} outline={lesson.is_approved} color={lesson.is_approved ? C.muted : C.mint} size="sm">
                {lesson.is_approved ? "Revoke" : "Approve"}
              </Btn>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Textbooks ─────────────────────────────────────────────────
function AdminTextbooks() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [learningPaths, setLearningPaths] = useState([]);
  const [selectedLp, setSelectedLp] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState(null);
  const fileRef = useRef(null);

  useEffect(() => {
    Promise.all([
      supabase.from('textbooks').select('*, learning_paths(name)').order('created_at', { ascending: false }),
      supabase.from('learning_paths').select('id, name, grade').eq('is_active', true).order('sort_order'),
    ]).then(([filesRes, lpRes]) => {
      setFiles(filesRes.data || []);
      setLearningPaths(lpRes.data || []);
      setLoading(false);
    });
  }, []);

  const handleFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!selectedLp || !title.trim()) { setError("Please select a class and enter a title"); return; }
    setUploading(true); setError(null);
    try {
      const fileName = `${Date.now()}-${file.name}`;
      // Try storage upload; fall back to just storing metadata if storage bucket not configured
      let fileUrl = null;
      const { error: uploadErr } = await supabase.storage.from('textbooks').upload(fileName, file);
      if (!uploadErr) {
        const { data: { publicUrl } } = supabase.storage.from('textbooks').getPublicUrl(fileName);
        fileUrl = publicUrl;
      }
      const { data: row, error: insertErr } = await supabase.from('textbooks').insert({
        learning_path_id: selectedLp,
        title: title.trim(),
        description: description.trim() || null,
        file_url: fileUrl,
        file_name: file.name,
        file_size: file.size,
        file_type: file.type,
      }).select('*, learning_paths(name)').single();
      if (insertErr) throw insertErr;
      setFiles(f => [row, ...f]);
      setTitle(""); setDescription(""); fileRef.current.value = "";
    } catch (err) { setError(err.message || "Upload failed"); }
    setUploading(false);
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this textbook?")) return;
    await supabase.from('textbooks').delete().eq('id', id);
    setFiles(f => f.filter(t => t.id !== id));
  };

  return (
    <div style={{ padding: 32 }}>
      <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>Textbooks</h1>
      <p style={{ color: C.muted, fontWeight: 600, marginBottom: 24 }}>Upload past questions, reference books, and syllabi.</p>
      <div className="card" style={{ padding: 24, marginBottom: 24 }}>
        <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 17, color: C.navy, marginBottom: 16 }}>Upload a textbook</div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, marginBottom: 6 }}>Title *</div>
            <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. WAEC Past Questions 2023"
              style={{ width: "100%", padding: "10px 14px", borderRadius: 12, border: `2px solid ${C.border}`, fontSize: 14, fontWeight: 600, color: C.navy, background: "#FAFAF8", boxSizing: "border-box" }} />
          </div>
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, marginBottom: 6 }}>Class / Exam *</div>
            <select value={selectedLp} onChange={e => setSelectedLp(e.target.value)}
              style={{ width: "100%", padding: "10px 14px", borderRadius: 12, border: `2px solid ${C.border}`, fontSize: 14, fontWeight: 600, color: C.navy, background: "#FAFAF8" }}>
              <option value="">Select class…</option>
              {learningPaths.map(lp => <option key={lp.id} value={lp.id}>{lp.name} ({lp.grade})</option>)}
            </select>
          </div>
        </div>
        <div style={{ marginBottom: 12 }}>
          <div style={{ fontSize: 12, fontWeight: 700, color: C.muted, marginBottom: 6 }}>Description (optional)</div>
          <input value={description} onChange={e => setDescription(e.target.value)} placeholder="Brief description…"
            style={{ width: "100%", padding: "10px 14px", borderRadius: 12, border: `2px solid ${C.border}`, fontSize: 14, fontWeight: 600, color: C.navy, background: "#FAFAF8", boxSizing: "border-box" }} />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <input ref={fileRef} type="file" accept=".pdf,.doc,.docx,.txt" onChange={handleFileChange} style={{ display: "none" }} />
          <Btn onClick={() => fileRef.current?.click()} disabled={uploading || !selectedLp || !title.trim()} color={C.fire}>
            {uploading ? "Uploading…" : "📄 Choose & Upload File"}
          </Btn>
          <div style={{ fontSize: 12, color: C.muted, fontWeight: 600 }}>PDF, DOC, or TXT</div>
        </div>
        {error && <div style={{ marginTop: 10, padding: "10px 14px", borderRadius: 12, background: `${C.rose}12`, border: `1.5px solid ${C.rose}33`, fontSize: 13, fontWeight: 700, color: C.rose }}>⚠️ {error}</div>}
      </div>
      {loading ? (
        [1,2].map(i => <div key={i} className="skeleton" style={{ height: 72, borderRadius: 16, marginBottom: 10 }} />)
      ) : files.length === 0 ? (
        <div className="card" style={{ padding: 32, textAlign: "center", color: C.muted }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>📄</div>
          <div style={{ fontWeight: 700 }}>No textbooks uploaded yet</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {files.map(f => (
            <div key={f.id} className="card" style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ fontSize: 28 }}>📄</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: C.navy }}>{f.title}</div>
                <div style={{ fontSize: 12, color: C.muted, fontWeight: 600 }}>
                  {f.learning_paths?.name} · {f.file_name} · {f.file_size ? `${Math.round(f.file_size/1024)}KB` : ""} · {new Date(f.created_at).toLocaleDateString()}
                </div>
              </div>
              {f.file_url && <a href={f.file_url} target="_blank" rel="noreferrer"><Btn outline color={C.sky} size="sm">View</Btn></a>}
              <Btn onClick={() => handleDelete(f.id)} outline color={C.rose} size="sm">Delete</Btn>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Users ─────────────────────────────────────────────────────
function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  useEffect(() => {
    supabase.from('user_profiles')
      .select('id, name, grade, mode, total_xp, streak, is_admin, created_at')
      .order('total_xp', { ascending: false })
      .then(({ data }) => { setUsers(data || []); setLoading(false); });
  }, []);

  const toggleAdmin = async (id, isAdmin) => {
    await supabase.from('user_profiles').update({ is_admin: !isAdmin }).eq('id', id);
    setUsers(us => us.map(u => u.id === id ? { ...u, is_admin: !isAdmin } : u));
  };

  const filtered = search
    ? users.filter(u => (u.name || "").toLowerCase().includes(search.toLowerCase()))
    : users;

  return (
    <div style={{ padding: 32 }}>
      <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>Users</h1>
      <p style={{ color: C.muted, fontWeight: 600, marginBottom: 20 }}>All registered students ({users.length} total)</p>
      <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search by name…"
        style={{ width: "100%", maxWidth: 400, padding: "10px 16px", borderRadius: 50, border: `2px solid ${C.border}`, fontSize: 14, fontWeight: 600, color: C.navy, background: "#fff", marginBottom: 20, boxSizing: "border-box" }} />
      {loading ? (
        [1,2,3,4,5].map(i => <div key={i} className="skeleton" style={{ height: 64, borderRadius: 16, marginBottom: 8 }} />)
      ) : filtered.length === 0 ? (
        <div className="card" style={{ padding: 32, textAlign: "center", color: C.muted }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>👥</div>
          <div style={{ fontWeight: 700 }}>No users found</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {filtered.map(u => (
            <div key={u.id} className="card" style={{ padding: "12px 18px", display: "flex", alignItems: "center", gap: 14 }}>
              <div style={{ width: 40, height: 40, borderRadius: 12, background: `linear-gradient(135deg,${C.fire}33,${C.sun}22)`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: C.fire, flexShrink: 0 }}>
                {(u.name || "?")[0].toUpperCase()}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontWeight: 800, fontSize: 14, color: C.navy }}>{u.name || "No name"}</div>
                <div style={{ fontSize: 11, color: C.muted, fontWeight: 600 }}>
                  {u.grade} · {u.mode} · ⭐ {u.total_xp || 0} XP · 🔥 {u.streak || 0} streak
                </div>
              </div>
              {u.is_admin && <Pill color={C.purple}>Admin</Pill>}
              <Btn onClick={() => toggleAdmin(u.id, u.is_admin)} outline={u.is_admin} color={u.is_admin ? C.rose : C.purple} size="sm">
                {u.is_admin ? "Remove Admin" : "Make Admin"}
              </Btn>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Flagged Questions ─────────────────────────────────────────
function AdminFlaggedQuestions() {
  const [flagged, setFlagged] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('flagged_questions')
      .select('id, flagged_at, reason, resolved, practice_questions(id, question, options, answer, explanation)')
      .order('flagged_at', { ascending: false })
      .then(({ data }) => { setFlagged(data || []); setLoading(false); });
  }, []);

  const resolve = async (id) => {
    await supabase.from('flagged_questions').update({ resolved: true }).eq('id', id);
    setFlagged(f => f.map(q => q.id === id ? { ...q, resolved: true } : q));
  };

  const dismiss = async (id) => {
    await supabase.from('flagged_questions').delete().eq('id', id);
    setFlagged(f => f.filter(q => q.id !== id));
  };

  const pending = flagged.filter(f => !f.resolved);
  const resolved = flagged.filter(f => f.resolved);

  return (
    <div style={{ padding: 32 }}>
      <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>Flagged Questions</h1>
      <p style={{ color: C.muted, fontWeight: 600, marginBottom: 24 }}>Questions students reported as incorrect. {pending.length} pending review.</p>
      {loading ? (
        [1,2,3].map(i => <div key={i} className="skeleton" style={{ height: 140, borderRadius: 16, marginBottom: 12 }} />)
      ) : flagged.length === 0 ? (
        <div className="card" style={{ padding: 40, textAlign: "center", color: C.muted }}>
          <div style={{ fontSize: 40, marginBottom: 10 }}>🚩</div>
          <div style={{ fontWeight: 700 }}>No flagged questions — great job!</div>
        </div>
      ) : (
        <>
          {pending.length > 0 && (
            <>
              <div style={{ fontWeight: 800, fontSize: 13, color: C.rose, letterSpacing: 0.8, marginBottom: 12 }}>PENDING REVIEW ({pending.length})</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 28 }}>
                {pending.map(f => {
                  const q = f.practice_questions;
                  const opts = q ? (Array.isArray(q.options) ? q.options : JSON.parse(q.options || "[]")) : [];
                  return (
                    <div key={f.id} className="card" style={{ padding: 20, border: `2px solid ${C.rose}33` }}>
                      <div style={{ fontWeight: 700, fontSize: 14, color: C.navy, marginBottom: 10 }}>{q?.question || "Question unavailable"}</div>
                      {opts.length > 0 && (
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10 }}>
                          {opts.map((opt, i) => (
                            <div key={i} style={{
                              padding: "4px 12px", borderRadius: 8, fontSize: 12, fontWeight: 700,
                              background: i === q?.answer ? `${C.mint}22` : "#F0EDE8",
                              border: `1.5px solid ${i === q?.answer ? C.mint : C.border}`,
                              color: i === q?.answer ? "#1a5c3a" : C.navy,
                            }}>{String.fromCharCode(65+i)}: {opt}</div>
                          ))}
                        </div>
                      )}
                      {q?.explanation && <div style={{ fontSize: 12, color: C.muted, fontWeight: 600, marginBottom: 10 }}>Explanation: {q.explanation}</div>}
                      <div style={{ fontSize: 11, color: C.muted, fontWeight: 600, marginBottom: 12 }}>
                        🚩 Flagged: {new Date(f.flagged_at).toLocaleString()} · Reason: {f.reason}
                      </div>
                      <div style={{ display: "flex", gap: 10 }}>
                        <Btn onClick={() => resolve(f.id)} color={C.mint} size="sm">✓ Mark Resolved</Btn>
                        <Btn onClick={() => dismiss(f.id)} outline color={C.rose} size="sm">Dismiss</Btn>
                      </div>
                    </div>
                  );
                })}
              </div>
            </>
          )}
          {resolved.length > 0 && (
            <>
              <div style={{ fontWeight: 800, fontSize: 13, color: C.mint, letterSpacing: 0.8, marginBottom: 12 }}>RESOLVED ({resolved.length})</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {resolved.map(f => (
                  <div key={f.id} className="card" style={{ padding: "12px 18px", display: "flex", alignItems: "center", gap: 12, opacity: 0.7 }}>
                    <span style={{ fontSize: 20 }}>✅</span>
                    <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: C.navy }}>{f.practice_questions?.question?.slice(0, 100)}…</div>
                    <Btn onClick={() => dismiss(f.id)} outline color={C.muted} size="sm">Remove</Btn>
                  </div>
                ))}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}
