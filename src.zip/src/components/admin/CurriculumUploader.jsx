// src/components/admin/CurriculumUploader.jsx
// ============================================================
// Admin tab for uploading curriculum per learning path.
// Supports: plain text, JSON paste, PDF (text extraction TBD).
// ============================================================

import { useState } from "react";
import { C } from '../../constants/colors';
import { useLearningPaths, useCurriculum } from '../../hooks/useData';
import Btn from '../ui/Btn';
import Pill from '../ui/Pill';

export default function CurriculumUploader() {
  const { data: learningPaths, loading: lpLoading } = useLearningPaths();
  const [selectedLp, setSelectedLp] = useState(null);
  const [inputMode,  setInputMode]  = useState("text");   // "text" | "json"
  const [rawText,    setRawText]    = useState("");
  const [saving,     setSaving]     = useState(false);
  const [saved,      setSaved]      = useState(false);
  const [saveError,  setSaveError]  = useState(null);

  const { files, upload } = useCurriculum(selectedLp?.id);

  const handleUpload = async () => {
    if (!selectedLp || !rawText.trim()) return;
    setSaving(true);
    setSaveError(null);

    const { error } = await upload({
      learningPathId: selectedLp.id,
      rawText:        rawText.trim(),
      fileType:       inputMode,
      originalName:   `${selectedLp.slug}-curriculum.${inputMode === 'json' ? 'json' : 'txt'}`,
    });

    setSaving(false);
    if (error) { setSaveError(error); }
    else { setSaved(true); setRawText(""); setTimeout(() => setSaved(false), 3000); }
  };

  return (
    <div style={{ padding: 32 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28 }}>
        <div>
          <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, marginBottom: 4 }}>
            Curriculum Upload
          </h1>
          <p style={{ color: C.muted, fontWeight: 600 }}>
            Upload curriculum content for each class or exam. AI will use this to generate all lessons.
          </p>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 24 }}>

        {/* ── LEFT: Learning path selector ── */}
        <div>
          <div style={{ fontWeight: 800, fontSize: 13, color: C.muted, letterSpacing: 0.8, marginBottom: 12 }}>
            SELECT CLASS / EXAM
          </div>
          {lpLoading ? (
            <div className="skeleton" style={{ height: 200, borderRadius: 16 }} />
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {learningPaths.map(lp => (
                <div key={lp.id} onClick={() => setSelectedLp(lp)} style={{
                  padding: "12px 16px", borderRadius: 14, cursor: "pointer",
                  border: `2px solid ${selectedLp?.id === lp.id ? C.fire : C.border}`,
                  background: selectedLp?.id === lp.id ? `${C.fire}10` : "#fff",
                  display: "flex", alignItems: "center", gap: 10,
                  transition: "all 0.18s",
                }}>
                  <span style={{ fontSize: 20 }}>{lp.icon || "📚"}</span>
                  <div>
                    <div style={{ fontWeight: 800, fontSize: 14, color: C.navy }}>{lp.name}</div>
                    <div style={{ fontSize: 11, color: C.muted, fontWeight: 600 }}>{lp.mode} · {lp.grade}</div>
                  </div>
                  {lp.has_curriculum && (
                    <Pill color={C.mint} style={{ marginLeft: "auto" }}>✓</Pill>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ── RIGHT: Upload form ── */}
        <div>
          {!selectedLp ? (
            <div style={{ height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: C.muted, fontWeight: 600, fontSize: 15 }}>
              ← Select a class or exam to upload curriculum
            </div>
          ) : (
            <>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 20, color: C.navy }}>
                  {selectedLp.icon} {selectedLp.name}
                </div>
                {selectedLp.has_curriculum && (
                  <Pill color={C.mint}>Curriculum uploaded ✓</Pill>
                )}
              </div>

              {/* Input mode toggle */}
              <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
                {[["text","Plain Text"],["json","JSON"]].map(([id, label]) => (
                  <div key={id} onClick={() => setInputMode(id)} style={{
                    padding: "7px 18px", borderRadius: 50, cursor: "pointer", fontWeight: 800, fontSize: 13,
                    border: `2px solid ${inputMode === id ? C.fire : C.border}`,
                    background: inputMode === id ? `${C.fire}12` : "#fff",
                    color: inputMode === id ? C.fire : C.muted,
                    transition: "all 0.18s",
                  }}>{label}</div>
                ))}
              </div>

              {/* Help text */}
              <div style={{ background: `${C.sky}12`, border: `1.5px solid ${C.sky}33`, borderRadius: 12, padding: "10px 14px", marginBottom: 14, fontSize: 13, fontWeight: 600, color: C.blue }}>
                {inputMode === "text"
                  ? "Paste your curriculum as plain text. Include topic names, subtopics, and any relevant descriptions. AI will use this to structure lessons."
                  : 'Paste curriculum as JSON. Format: [{"topic":"Algebra","subtopics":["Linear Equations","Quadratic Equations"]}]'}
              </div>

              {/* Text input */}
              <textarea
                value={rawText}
                onChange={e => setRawText(e.target.value)}
                placeholder={inputMode === "text"
                  ? "Paste curriculum text here...\n\nExample:\nTopic 1: Algebra\n- Linear Equations\n- Quadratic Equations\n- Simultaneous Equations\n\nTopic 2: Geometry..."
                  : '[{"topic":"Algebra","subtopics":["Linear Equations","Quadratic Equations"]}]'
                }
                rows={14}
                style={{
                  width: "100%", padding: "14px 16px", borderRadius: 16, resize: "vertical",
                  border: `2px solid ${C.border}`, fontSize: 14, fontWeight: 600,
                  color: C.navy, background: "#FAFAF8", fontFamily: inputMode === "json" ? "monospace" : "'Nunito'",
                  lineHeight: 1.65,
                }}
              />

              {saveError && (
                <div style={{ marginTop: 10, padding: "10px 14px", borderRadius: 12, background: `${C.rose}12`, border: `1.5px solid ${C.rose}33`, fontSize: 13, fontWeight: 700, color: C.rose }}>
                  ⚠️ {saveError}
                </div>
              )}

              <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
                <Btn
                  onClick={handleUpload}
                  disabled={saving || !rawText.trim()}
                  size="lg"
                  style={{ flex: 1 }}
                >
                  {saving ? "Saving…" : saved ? "✅ Saved!" : "📤 Upload Curriculum"}
                </Btn>
                {rawText && (
                  <Btn onClick={() => setRawText("")} outline color={C.muted} size="lg">Clear</Btn>
                )}
              </div>

              {/* Existing files */}
              {files.length > 0 && (
                <div style={{ marginTop: 24 }}>
                  <div style={{ fontWeight: 800, fontSize: 13, color: C.muted, letterSpacing: 0.8, marginBottom: 10 }}>
                    UPLOADED FILES
                  </div>
                  {files.map((f, i) => (
                    <div key={f.id} style={{ background: "#fff", borderRadius: 14, padding: "12px 16px", marginBottom: 8, boxShadow: "0 2px 0 #E0D8CE", display: "flex", alignItems: "center", gap: 12 }}>
                      <div style={{ fontSize: 22 }}>📄</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 700, fontSize: 13, color: C.navy }}>{f.original_name}</div>
                        <div style={{ fontSize: 11, color: C.muted, fontWeight: 600 }}>
                          {f.file_type.toUpperCase()} · {new Date(f.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <Pill color={f.processed ? C.mint : C.sun}>
                        {f.processed ? "Ready" : "Processing"}
                      </Pill>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
