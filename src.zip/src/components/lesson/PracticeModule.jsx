import { useState, useRef, useEffect } from "react";
import { C } from '../../constants/colors';
import { useExtendedQuestions, useLesson } from '../../hooks/useContent';
import { flagQuestion } from '../../services/content';

import Btn from '../ui/Btn';
import Pill from '../ui/Pill';
import ProgressBar from '../ui/ProgressBar';

// Fisher-Yates shuffle (non-mutating)
function shuffleArray(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

// ── Setup Screen ──
function PracticeSetup({ subtopicName, questionCount, onStart, onBack }) {
  const [mode,  setMode]  = useState(null);
  const [count, setCount] = useState(10);
  const [mins,  setMins]  = useState(1);
  const ready = mode !== null;

  return (
    <div style={{ maxWidth: 520, margin: "0 auto", padding: "28px 16px 100px" }}>
      <button className="btn" onClick={onBack} style={{ background: "transparent", color: C.muted, fontSize: 14, fontWeight: 700, marginBottom: 24, gap: 4 }}>
        ← Back to Lesson
      </button>

      <div className="anim-fadeUp" style={{ marginBottom: 24 }}>
        <Pill color={C.purple}>🎯 Practice Mode</Pill>
        <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, margin: "10px 0 4px" }}>Practice More</h1>
        <p style={{ color: C.muted, fontWeight: 600 }}>{subtopicName} · {questionCount} questions in the pool</p>
      </div>

      {/* Mode selector */}
      <div className="card anim-fadeUp" style={{ padding: 24, marginBottom: 16 }}>
        <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 17, color: C.navy, marginBottom: 14 }}>
          How do you want to practice?
        </div>
        <div style={{ display: "flex", gap: 12 }}>
          {[
            { id: "count", icon: "🔢", label: "By Questions" },
            { id: "time",  icon: "⏱️", label: "By Time"      },
          ].map(({ id, icon, label }) => (
            <div key={id} onClick={() => setMode(id)} style={{
              flex: 1, padding: "18px 14px", borderRadius: 18, textAlign: "center", cursor: "pointer",
              border: `2.5px solid ${mode === id ? C.purple : C.border}`,
              background: mode === id ? `${C.purple}12` : "#fff",
              transition: "all 0.2s",
            }}>
              <div style={{ fontSize: 32, marginBottom: 6 }}>{icon}</div>
              <div style={{ fontWeight: 800, fontSize: 14, color: mode === id ? C.purple : C.navy }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Count options */}
      {mode === "count" && (
        <div className="card anim-fadeUp" style={{ padding: 24, marginBottom: 16 }}>
          <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 16, color: C.navy, marginBottom: 12 }}>
            How many questions?
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            {[10, 20, "∞"].map(v => {
              const val = v === "∞" ? "unlimited" : v;
              return (
                <div key={v} onClick={() => setCount(val)} style={{
                  flex: 1, padding: "16px 8px", borderRadius: 16, textAlign: "center", cursor: "pointer",
                  border: `2.5px solid ${count === val ? C.fire : C.border}`,
                  background: count === val ? `${C.fire}12` : "#fff",
                  fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 22,
                  color: count === val ? C.fire : C.navy,
                  transition: "all 0.2s",
                }}>
                  {v}
                  <div style={{ fontSize: 11, fontWeight: 700, color: C.muted, marginTop: 2 }}>
                    {v === 10 ? "Quick" : v === 20 ? "Standard" : "Unlimited"}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Time options */}
      {mode === "time" && (
        <div className="card anim-fadeUp" style={{ padding: 24, marginBottom: 16 }}>
          <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 16, color: C.navy, marginBottom: 12 }}>
            How long?
          </div>
          <div style={{ display: "flex", gap: 10 }}>
            {[1, 2, 5].map(m => (
              <div key={m} onClick={() => setMins(m)} style={{
                flex: 1, padding: "16px 8px", borderRadius: 16, textAlign: "center", cursor: "pointer",
                border: `2.5px solid ${mins === m ? C.sky : C.border}`,
                background: mins === m ? `${C.sky}12` : "#fff",
                fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 22,
                color: mins === m ? C.sky : C.navy,
                transition: "all 0.2s",
              }}>
                {m}m
                <div style={{ fontSize: 11, fontWeight: 700, color: C.muted, marginTop: 2 }}>
                  {m === 1 ? "Sprint" : m === 2 ? "Standard" : "Marathon"}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Btn
        onClick={() => ready && onStart({ mode, count, mins })}
        disabled={!ready}
        size="lg"
        color={C.purple}
        style={{ width: "100%", marginTop: 8, boxShadow: `0 5px 0 ${C.purple}66` }}
      >
        Start Practising 🚀
      </Btn>
    </div>
  );
}

// ── Summary Screen ──
function PracticeSummary({ correct, total, accuracy, onRetry, onLesson }) {
  return (
    <div style={{ maxWidth: 520, margin: "0 auto", padding: "28px 16px 100px" }}>
      <div className="card anim-popIn" style={{ padding: 36, textAlign: "center", marginBottom: 20 }}>
        <div style={{ fontSize: 64, marginBottom: 12 }}>
          {accuracy >= 80 ? "🏆" : accuracy >= 50 ? "💪" : "📚"}
        </div>
        <h2 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 28, color: C.navy, marginBottom: 6 }}>
          Session Complete!
        </h2>
        <p style={{ color: C.muted, fontWeight: 600, marginBottom: 24 }}>Here's how you did:</p>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14, marginBottom: 28 }}>
          {[
            { label: "Correct",   value: correct,        icon: "✅", color: C.mint },
            { label: "Attempted", value: total,           icon: "🔢", color: C.sky  },
            { label: "Accuracy",  value: `${accuracy}%`, icon: "🎯", color: accuracy >= 80 ? C.mint : accuracy >= 50 ? C.sun : C.rose },
          ].map(({ label, value, icon, color }) => (
            <div key={label} className="card" style={{ padding: 16, textAlign: "center" }}>
              <div style={{ fontSize: 22, marginBottom: 4 }}>{icon}</div>
              <div style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 24, color }}>{value}</div>
              <div style={{ fontSize: 11, color: C.muted, fontWeight: 700 }}>{label}</div>
            </div>
          ))}
        </div>

        <ProgressBar
          pct={accuracy}
          color={accuracy >= 80 ? C.mint : accuracy >= 50 ? C.sun : C.rose}
          height={12}
        />
        <p style={{ color: C.muted, fontSize: 13, fontWeight: 600, marginTop: 8 }}>
          {accuracy >= 80
            ? "Outstanding! You've mastered this topic! 🌟"
            : accuracy >= 50
            ? "Good work! Keep practising to improve. 💪"
            : "Keep at it — revision makes perfect! 📖"}
        </p>
      </div>

      <div style={{ display: "flex", gap: 12 }}>
        <Btn onClick={onRetry}  size="lg" color={C.purple} outline style={{ flex: 1 }}>🔄 Retry</Btn>
        <Btn onClick={onLesson} size="lg" color={C.mint}   style={{ flex: 1, boxShadow: `0 5px 0 ${C.mint}66` }}>📖 Back to Lesson</Btn>
      </div>
    </div>
  );
}

// ── Active Session ──
function PracticeSession({ questions, config, onFinish, onBack }) {
  const pool         = useRef(shuffleArray(questions));
  const limit        = config.mode === "count"
    ? (config.count === "unlimited" ? Infinity : config.count)
    : Infinity;
  const totalSeconds = config.mode === "time" ? config.mins * 60 : null;

  const [qIndex,    setQIndex]    = useState(0);
  const [selected,  setSelected]  = useState(null);
  const [confirmed, setConfirmed] = useState(false);
  const [results,   setResults]   = useState([]);
  const [timeLeft,  setTimeLeft]  = useState(totalSeconds);
  const [done,      setDone]      = useState(false);
  const [flagged,   setFlagged]   = useState({});  // questionId → true
  const [flagging,  setFlagging]  = useState(false);

  const currentQ = pool.current[qIndex % pool.current.length];

  const handleFlag = async () => {
    if (!currentQ?.id || flagged[currentQ.id] || flagging) return;
    setFlagging(true);
    try {
      await flagQuestion(currentQ.id);
      setFlagged(f => ({ ...f, [currentQ.id]: true }));
    } catch (e) {
      console.error('Flag failed:', e);
    }
    setFlagging(false);
  };

  // Countdown timer — only active in time mode
  useEffect(() => {
    if (totalSeconds === null || done) return;
    if (timeLeft <= 0) { setDone(true); return; }
    const id = setTimeout(() => setTimeLeft(t => t - 1), 1000);
    return () => clearTimeout(id);
  }, [timeLeft, done, totalSeconds]);

  const advance = (res) => {
    const nextIndex = qIndex + 1;
    if (nextIndex >= limit) {
      setDone(true);
    } else {
      setQIndex(nextIndex);
      setSelected(null);
      setConfirmed(false);
    }
  };

  const handleConfirm = () => {
    if (selected === null) return;
    const isCorrect  = selected === currentQ.answer;
    const newResults = [...results, { correct: isCorrect }];
    setConfirmed(true);
    setResults(newResults);
    // Time mode auto-advances after 1.4s; count mode waits for "Next" button
    if (config.mode === "time") {
      setTimeout(() => advance(newResults), 1400);
    }
  };

  // Show summary when session ends
  if (done) {
    const correct  = results.filter(r => r.correct).length;
    const total    = results.length;
    const accuracy = total > 0 ? Math.round(correct / total * 100) : 0;
    return (
      <PracticeSummary
        correct={correct}
        total={total}
        accuracy={accuracy}
        onRetry={onBack}
        onLesson={onFinish}
      />
    );
  }

  const pct     = config.mode === "count" && config.count !== "unlimited"
    ? Math.round((qIndex / config.count) * 100)
    : 0;
  const timePct = totalSeconds
    ? Math.round(((totalSeconds - timeLeft) / totalSeconds) * 100)
    : 0;
  const displayMins = Math.floor((timeLeft || 0) / 60);
  const displaySecs = (timeLeft || 0) % 60;

  return (
    <div style={{ maxWidth: 560, margin: "0 auto", padding: "28px 16px 100px" }}>

      {/* Header bar */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <button className="btn" onClick={onBack} style={{ background: "transparent", color: C.muted, fontSize: 14, fontWeight: 700 }}>
          ✕ Exit
        </button>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          {config.mode === "time" && (
            <div style={{
              background: timeLeft <= 10 ? `${C.rose}18` : `${C.sky}15`,
              border: `2px solid ${timeLeft <= 10 ? C.rose : C.sky}44`,
              borderRadius: 50, padding: "4px 16px",
              fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 18,
              color: timeLeft <= 10 ? C.rose : C.sky,
            }}>
              ⏱ {displayMins}:{String(displaySecs).padStart(2, "0")}
            </div>
          )}
          <Pill color={C.purple}>
            {config.mode === "count" && config.count !== "unlimited"
              ? `${qIndex + 1}/${config.count}`
              : `Q${qIndex + 1}`}
          </Pill>
          <Pill color={C.mint}>✓ {results.filter(r => r.correct).length}</Pill>
        </div>
      </div>

      {/* Progress bars */}
      {config.mode === "count" && config.count !== "unlimited" && (
        <div style={{ marginBottom: 20 }}>
          <ProgressBar pct={pct} color={C.purple} />
        </div>
      )}
      {config.mode === "time" && (
        <div style={{ marginBottom: 20 }}>
          <ProgressBar pct={timePct} color={timeLeft <= 10 ? C.rose : C.sky} />
        </div>
      )}

      {/* Question card — key={qIndex} forces re-mount animation on each question */}
      <div className="card anim-scaleIn" key={qIndex} style={{ padding: 28, marginBottom: 18 }}>
        <div style={{ display: "flex", gap: 12, marginBottom: 20, alignItems: "flex-start" }}>
          <div style={{
            width: 36, height: 36, borderRadius: 12, flexShrink: 0,
            background: `linear-gradient(135deg,${C.purple},${C.sky})`,
            display: "flex", alignItems: "center", justifyContent: "center",
            fontSize: 15, fontWeight: 900, color: "#fff",
          }}>Q</div>
          <p style={{ fontWeight: 700, fontSize: 16, color: C.navy, lineHeight: 1.55, paddingTop: 5 }}>
            {currentQ.question}
          </p>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {currentQ.options.map((opt, oi) => {
            let bg = "#F8F5F0", border = C.border, color2 = C.navy;
            if (!confirmed && selected === oi)                           { bg = `${C.purple}12`; border = C.purple; color2 = C.purple; }
            if (confirmed && oi === currentQ.answer)                     { bg = `${C.mint}18`;   border = C.mint;   color2 = C.mint;   }
            if (confirmed && oi === selected && oi !== currentQ.answer)  { bg = `${C.rose}12`;   border = C.rose;   color2 = C.rose;   }

            return (
              <div
                key={oi}
                className="option-btn"
                onClick={() => !confirmed && setSelected(oi)}
                style={{
                  padding: "13px 18px", borderRadius: 16,
                  border: `2.5px solid ${border}`,
                  background: bg, color: color2,
                  fontWeight: 700, fontSize: 15,
                  cursor: confirmed ? "default" : "pointer",
                  display: "flex", alignItems: "center", gap: 8,
                }}
              >
                <span style={{
                  width: 24, height: 24, borderRadius: 8, flexShrink: 0,
                  background: `${border}22`,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 12, fontWeight: 900,
                }}>
                  {confirmed
                    ? (oi === currentQ.answer ? "✓" : oi === selected ? "✗" : String.fromCharCode(65 + oi))
                    : String.fromCharCode(65 + oi)}
                </span>
                {opt}
              </div>
            );
          })}
        </div>
      </div>

      {/* Action buttons */}
      {!confirmed && (
        <Btn
          onClick={handleConfirm}
          disabled={selected === null}
          size="lg"
          color={C.purple}
          style={{ width: "100%", boxShadow: `0 5px 0 ${C.purple}66` }}
        >
          Confirm Answer
        </Btn>
      )}
      {confirmed && config.mode === "count" && (
        <Btn
          onClick={() => advance(results)}
          size="lg"
          color={C.sky}
          style={{ width: "100%", boxShadow: `0 5px 0 ${C.sky}66` }}
        >
          Next Question →
        </Btn>
      )}
      {/* Flag incorrect question */}
      {confirmed && (
        <div style={{ marginTop: 10, textAlign: "center" }}>
          <button
            onClick={handleFlag}
            disabled={flagged[currentQ?.id] || flagging}
            style={{
              background: "transparent", border: "none", cursor: flagged[currentQ?.id] ? "default" : "pointer",
              fontSize: 12, fontWeight: 700,
              color: flagged[currentQ?.id] ? C.muted : C.rose,
              padding: "4px 8px", borderRadius: 8,
              opacity: flagged[currentQ?.id] ? 0.5 : 1,
            }}
          >
            {flagged[currentQ?.id] ? "✓ Question flagged — thanks!" : "🚩 Flag this question as incorrect"}
          </button>
        </div>
      )}
    </div>
  );
}

// ── Top-level orchestrator: Setup → Session → Summary ──
export default function PracticeModule({ subtopicId, subtopic, onBack }) {
  const [practicePhase, setPracticePhase] = useState("setup");
  const [sessionConfig, setSessionConfig] = useState(null);

  // Fetch the lesson for this subtopic so we can get its ID for extended questions
  const { lesson, questions: lessonQuestions, loading: lessonLoading } = useLesson(subtopicId);

  // Fetch extended (practice-pool) questions — only fires once lesson.id is known
  const { data: extendedQuestions, loading: extLoading } = useExtendedQuestions(lesson?.id ?? null);

  // Use extended questions if available, fall back to lesson gate questions
  const questions = extendedQuestions?.length
    ? extendedQuestions
    : lessonQuestions || [];

  const loading = lessonLoading || extLoading;

  if (loading) {
    return (
      <div style={{ maxWidth: 480, margin: "0 auto", padding: "80px 24px", textAlign: "center" }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>⏳</div>
        <div style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 22, color: C.navy }}>
          Loading questions…
        </div>
      </div>
    );
  }

  if (!questions.length) {
    return (
      <div style={{ maxWidth: 480, margin: "0 auto", padding: "80px 24px", textAlign: "center" }}>
        <div style={{ fontSize: 48, marginBottom: 16 }}>📭</div>
        <div style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 22, color: C.navy, marginBottom: 10 }}>
          No practice questions yet
        </div>
        <p style={{ color: C.muted, fontWeight: 600, marginBottom: 24 }}>
          Questions for <strong>{subtopic?.name}</strong> haven't been generated yet.
        </p>
        <Btn onClick={onBack} outline color={C.muted}>← Back to Lesson</Btn>
      </div>
    );
  }

  if (practicePhase === "session" && sessionConfig) {
    return (
      <PracticeSession
        questions={questions}
        config={sessionConfig}
        onFinish={onBack}
        onBack={() => setPracticePhase("setup")}
      />
    );
  }

  return (
    <PracticeSetup
      subtopicName={subtopic?.name || "Topic"}
      questionCount={questions.length}
      onStart={config => {
        setSessionConfig(config);
        setPracticePhase("session");
      }}
      onBack={onBack}
    />
  );
}