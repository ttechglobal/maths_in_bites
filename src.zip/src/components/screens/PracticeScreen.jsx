import { useState } from "react";
import { C } from '../../constants/colors';
import { PAGE_ACCENTS } from '../../constants/accents';
import { useSubtopics } from '../../hooks/useContent';
import Pill from '../ui/Pill';
import PracticeModule from '../lesson/PracticeModule';
import { ListSkeleton } from '../states/ContentStates';

// ── Step 1: Pick a topic ─────────────────────────────────────
function PracticeTopicPicker({ topics, onSelect }) {
  const accent = PAGE_ACCENTS.practice;
  return (
    <div style={{ maxWidth: 560, margin: "0 auto", padding: "28px 16px 100px" }}>
      <div className="anim-fadeUp" style={{ marginBottom: 24 }}>
        <Pill color={accent.primary}>🎯 Practice</Pill>
        <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 32, color: C.navy, margin: "10px 0 4px" }}>Pick a Topic</h1>
        <p style={{ color: C.muted, fontWeight: 600 }}>Choose a topic to practise questions from</p>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {topics.map((t, idx) => (
          <div key={t.id} className="card anim-fadeUp" style={{
            padding: "18px 22px", cursor: "pointer", animationDelay: `${idx * 0.06}s`,
            display: "flex", alignItems: "center", gap: 14,
          }} onClick={() => onSelect(t)}>
            <div style={{
              width: 46, height: 46, borderRadius: 14, flexShrink: 0,
              background: `linear-gradient(135deg,${accent.primary}33,${accent.secondary}22)`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 24, border: `2px solid ${accent.primary}44`,
            }}>{t.icon || "📖"}</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 17, color: C.navy }}>{t.name}</div>
              <div style={{ fontSize: 12, color: C.muted, fontWeight: 600, marginTop: 2 }}>
                Tap to see subtopics
              </div>
            </div>
            <div style={{ fontSize: 20, color: C.border }}>›</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Step 2: Pick a subtopic within the topic ─────────────────
function PracticeSubtopicPicker({ topic, grade, onSelect, onBack }) {
  const accent = PAGE_ACCENTS.practice;
  const { data: subtopics, status } = useSubtopics(topic?.id, grade ?? null, topic?.name ?? null);

  return (
    <div style={{ maxWidth: 560, margin: "0 auto", padding: "28px 16px 100px" }}>
      <button className="btn" onClick={onBack} style={{ background: "transparent", color: C.muted, fontSize: 14, fontWeight: 700, marginBottom: 20 }}>
        ← Back to Topics
      </button>
      <div className="anim-fadeUp" style={{ marginBottom: 24 }}>
        <div style={{ fontSize: 40, marginBottom: 8 }}>{topic?.icon || "📖"}</div>
        <h1 style={{ fontFamily: "'Baloo 2'", fontWeight: 900, fontSize: 28, color: C.navy, marginBottom: 4 }}>{topic?.name}</h1>
        <p style={{ color: C.muted, fontWeight: 600 }}>Choose a subtopic to practise</p>
      </div>

      {(status === 'loading' || status === 'generating') && <ListSkeleton count={3} height={68} />}

      {status === 'ready' && subtopics.length === 0 && (
        <div style={{ textAlign: "center", padding: "40px 0", color: C.muted, fontWeight: 600 }}>
          No subtopics available yet.
        </div>
      )}

      {status === 'ready' && subtopics.length > 0 && (
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {subtopics.map((sub, idx) => (
            <div key={sub.id} className="card anim-fadeUp" style={{
              padding: "18px 22px", cursor: "pointer", animationDelay: `${idx * 0.06}s`,
              display: "flex", alignItems: "center", gap: 14,
            }} onClick={() => onSelect(sub)}>
              <div style={{
                width: 42, height: 42, borderRadius: 14, flexShrink: 0,
                background: `linear-gradient(135deg,${accent.primary}22,${accent.secondary}11)`,
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 20, border: `2px solid ${accent.primary}33`,
              }}>🎯</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: "'Baloo 2'", fontWeight: 800, fontSize: 16, color: C.navy }}>{sub.name}</div>
                <div style={{ fontSize: 12, color: C.muted, fontWeight: 600, marginTop: 2 }}>Tap to practise</div>
              </div>
              <div style={{ fontSize: 20, color: C.border }}>›</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ── Root PracticeScreen ──────────────────────────────────────
export default function PracticeScreen({ topics, grade }) {
  const [step,           setStep]           = useState("topic");
  const [activeTopic,    setActiveTopic]    = useState(null);
  const [activeSubtopic, setActiveSubtopic] = useState(null);

  if (step === "practice" && activeSubtopic) {
    return (
      <PracticeModule
        subtopicId={activeSubtopic.id}
        subtopic={activeSubtopic}
        onBack={() => setStep("subtopic")}
      />
    );
  }

  if (step === "subtopic" && activeTopic) {
    return (
      <PracticeSubtopicPicker
        topic={activeTopic}
        grade={grade}
        onSelect={sub => { setActiveSubtopic(sub); setStep("practice"); }}
        onBack={() => setStep("topic")}
      />
    );
  }

  return (
    <PracticeTopicPicker
      topics={topics}
      onSelect={t => { setActiveTopic(t); setStep("subtopic"); }}
    />
  );
}
