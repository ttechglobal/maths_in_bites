export const PAGE_ACCENTS = {
  home:     { primary: "#03A9F4", secondary: "#4FC3F7", label: "sky"    },
  learn:    { primary: "#7B1FA2", secondary: "#AB47BC", label: "indigo" },
  practice: { primary: "#FF7043", secondary: "#FFB74D", label: "orange" },
  settings: { primary: "#607D8B", secondary: "#90A4AE", label: "slate"  },
};