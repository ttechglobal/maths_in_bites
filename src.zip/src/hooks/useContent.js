// src/hooks/useContent.js
// ============================================================
// Clean, unified content hooks. One file. No duplication.
//
// All hooks follow the same pattern:
//   status: 'idle' | 'loading' | 'generating' | 'ready' | 'error'
//
// CONTENT FLOW:
//   useTopics      → seed from curriculum → DB
//   useSubtopics   → AI generates from curriculum hints → DB → poll
//   useLesson      → AI generates → DB → poll
//   useProgress    → Supabase user_progress table
// ============================================================

import { useState, useEffect, useRef, useCallback } from 'react';
import * as content from '../services/content';

// ── Polling helper ────────────────────────────────────────────
// Runs `fetchFn` every `intervalMs` until `isDone(result)` is true.
// Returns a cleanup function.
function startPolling(fetchFn, onResult, isDone, intervalMs = 3000) {
  let stopped = false;
  const tick = async () => {
    if (stopped) return;
    const result = await fetchFn();
    if (stopped) return;
    onResult(result);
    if (!isDone(result) && !stopped) {
      setTimeout(tick, intervalMs);
    }
  };
  setTimeout(tick, intervalMs); // first check after initial delay
  return () => { stopped = true; };
}

// ── HOOK: useTopics ───────────────────────────────────────────
// 1. Fetch existing topics from DB
// 2. If none → seed from curriculum constant (instant, no AI)
// 3. Return topics with status
export function useTopics(learningPathId, grade) {
  const [topics, setTopics]   = useState([]);
  const [status, setStatus]   = useState('idle');
  const [error,  setError]    = useState(null);
  const seededRef = useRef(false);

  const loadTopics = useCallback(async () => {
    if (!learningPathId) { setStatus('idle'); return; }
    setStatus('loading');
    setError(null);

    try {
      const rows = await content.getTopics(learningPathId);

      if (rows.length > 0) {
        setTopics(rows);
        setStatus('ready');
        return;
      }

      // No topics yet — seed from curriculum (no AI, fast)
      if (!grade || seededRef.current) {
        setStatus('no_curriculum');
        return;
      }

      seededRef.current = true;
      const inserted = await content.seedTopicsFromCurriculum(learningPathId, grade);

      if (inserted === 0) {
        setStatus('no_curriculum');
        return;
      }

      // Re-fetch after seeding
      const fresh = await content.getTopics(learningPathId);
      setTopics(fresh);
      setStatus('ready');

    } catch (e) {
      console.error('[useTopics] error:', e);
      setError(e.message);
      setStatus('error');
    }
  }, [learningPathId, grade]);

  useEffect(() => {
    seededRef.current = false;
    loadTopics();
  }, [loadTopics]);

  return { topics, status, error, loading: status === 'loading' };
}

// ── HOOK: useSubtopics ────────────────────────────────────────
// 1. Fetch subtopics from DB
// 2. If none (or all non-AI) → trigger AI generation
// 3. Poll until AI subtopics appear
//
// The AI receives the topic name + curriculum hints (subtopics + objectives)
// and generates better, progressive, bite-sized subtopics.
export function useSubtopics(topicId, grade, topicName) {
  const [subtopics, setSubtopics] = useState([]);
  const [status,    setStatus]    = useState('idle');
  const [error,     setError]     = useState(null);
  const stopPollRef = useRef(null);
  const triggeredRef = useRef(false);

  const stopPolling = useCallback(() => {
    stopPollRef.current?.();
    stopPollRef.current = null;
  }, []);

  useEffect(() => {
    if (!topicId) { setStatus('idle'); setSubtopics([]); return; }
    setStatus('loading');
    setError(null);
    triggeredRef.current = false;
    stopPolling();

    let cancelled = false;

    async function load() {
      try {
        const rows = await content.getSubtopics(topicId);
        if (cancelled) return;

        const aiRows = content.filterAiSubtopics(rows);

        if (aiRows.length > 0) {
          // AI subtopics exist — we're done
          setSubtopics(aiRows);
          setStatus('ready');
          return;
        }

        // No AI subtopics yet — trigger generation
        if (!triggeredRef.current) {
          triggeredRef.current = true;
          setStatus('generating');

          // Fire and forget — we'll poll for the result
          content.triggerSubtopicGeneration(topicId, topicName, grade)
            .catch(e => console.error('[useSubtopics] trigger failed:', e));
        }

        // Poll for AI subtopics
        if (cancelled) return;
        stopPollRef.current = startPolling(
          () => content.getSubtopics(topicId),
          (polled) => {
            if (cancelled) return;
            const ai = content.filterAiSubtopics(polled);
            if (ai.length > 0) {
              setSubtopics(ai);
              setStatus('ready');
              stopPolling();
            }
          },
          (polled) => content.filterAiSubtopics(polled).length > 0,
          3000
        );

      } catch (e) {
        if (cancelled) return;
        console.error('[useSubtopics] error:', e);
        setError(e.message);
        setStatus('error');
      }
    }

    load();

    return () => {
      cancelled = true;
      stopPolling();
    };
  }, [topicId, grade, topicName, stopPolling]);

  return {
    subtopics,
    status,
    error,
    loading:      status === 'loading' || status === 'generating',
    isGenerating: status === 'generating',
  };
}

// ── HOOK: useLesson ───────────────────────────────────────────
// 1. Fetch lesson from DB
// 2. If none → trigger AI generation
// 3. Poll until lesson appears
// 4. Also fetches examples and lesson-gate questions
export function useLesson(subtopicId) {
  const [lesson,    setLesson]    = useState(null);
  const [examples,  setExamples]  = useState([]);
  const [questions, setQuestions] = useState([]);
  const [status,    setStatus]    = useState('idle');
  const [error,     setError]     = useState(null);
  const stopPollRef  = useRef(null);
  const triggeredRef = useRef(false);

  const stopPolling = useCallback(() => {
    stopPollRef.current?.();
    stopPollRef.current = null;
  }, []);

  const fetchLessonData = useCallback(async (lessonRow) => {
    const [examples, questions] = await Promise.all([
      content.getLessonExamples(lessonRow.id),
      content.getLessonQuestions(lessonRow.id, 'lesson'),
    ]);
    return { examples, questions };
  }, []);

  useEffect(() => {
    if (!subtopicId) { setStatus('idle'); setLesson(null); return; }
    setStatus('loading');
    setError(null);
    triggeredRef.current = false;
    stopPolling();

    let cancelled = false;

    async function load() {
      try {
        const lessonRow = await content.getLesson(subtopicId);
        if (cancelled) return;

        if (lessonRow) {
          const { examples, questions } = await fetchLessonData(lessonRow);
          if (cancelled) return;
          setLesson(lessonRow);
          setExamples(examples);
          setQuestions(questions);
          setStatus('ready');
          return;
        }

        // No lesson — trigger AI generation
        if (!triggeredRef.current) {
          triggeredRef.current = true;
          setStatus('generating');

          content.triggerLessonGeneration(subtopicId)
            .catch(e => console.error('[useLesson] trigger failed:', e));
        }

        if (cancelled) return;
        stopPollRef.current = startPolling(
          () => content.getLesson(subtopicId),
          async (polled) => {
            if (!polled || cancelled) return;
            const { examples, questions } = await fetchLessonData(polled);
            if (cancelled) return;
            setLesson(polled);
            setExamples(examples);
            setQuestions(questions);
            setStatus('ready');
            stopPolling();
          },
          (polled) => polled !== null,
          3000
        );

      } catch (e) {
        if (cancelled) return;
        console.error('[useLesson] error:', e);
        setError(e.message);
        setStatus('error');
      }
    }

    load();

    return () => {
      cancelled = true;
      stopPolling();
    };
  }, [subtopicId, fetchLessonData, stopPolling]);

  return {
    lesson,
    examples,
    questions,
    status,
    error,
    loading:      status === 'loading' || status === 'generating',
    isGenerating: status === 'generating',
  };
}

// ── HOOK: useExtendedQuestions ────────────────────────────────
// Extended practice questions — the bigger question pool for the
// Practice More mode. Fetched separately to keep lesson loading fast.
export function useExtendedQuestions(lessonId) {
  const [questions, setQuestions] = useState([]);
  const [loading,   setLoading]   = useState(false);

  useEffect(() => {
    if (!lessonId) { setQuestions([]); return; }
    let cancelled = false;
    setLoading(true);
    content.getLessonQuestions(lessonId, 'extended')
      .then(qs => { if (!cancelled) { setQuestions(qs); setLoading(false); } })
      .catch(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [lessonId]);

  return { questions, loading };
}

// ── HOOK: useProgress ─────────────────────────────────────────
export function useProgress(userId) {
  const [completedIds, setCompletedIds] = useState([]);

  const refresh = useCallback(async () => {
    if (!userId) return;
    const ids = await content.getCompletedSubtopicIds(userId);
    setCompletedIds(ids);
  }, [userId]);

  useEffect(() => { refresh(); }, [refresh]);

  const save = useCallback(async (subtopicId, score, xpEarned) => {
    if (!userId) return;
    await content.saveProgress(userId, subtopicId, score, xpEarned);
    await refresh();
  }, [userId, refresh]);

  return { completedIds, saveProgress: save, refresh };
}

// ── HOOK: useLearningPath ─────────────────────────────────────
export function useLearningPath(grade, mode) {
  const [learningPath, setLearningPath] = useState(null);
  const [loading,      setLoading]      = useState(false);

  useEffect(() => {
    if (!grade || !mode) { setLearningPath(null); return; }
    let cancelled = false;
    setLoading(true);
    content.getLearningPath(grade, mode)
      .then(lp => { if (!cancelled) { setLearningPath(lp); setLoading(false); } })
      .catch(() => { if (!cancelled) setLoading(false); });
    return () => { cancelled = true; };
  }, [grade, mode]);

  return { learningPath, loading };
}
