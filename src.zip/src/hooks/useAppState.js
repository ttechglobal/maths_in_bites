// src/hooks/useAppState.js
// ============================================================
// Root app state — Supabase-powered.
// Includes the learning path resolver (grade → learning_path row).
// ============================================================

import { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useProfile } from './useData';

export function useAppState() {
  // ── Auth ──────────────────────────────────────────────────
  const [authUser,  setAuthUser]  = useState(null);
  const [authReady, setAuthReady] = useState(false);

  // ── Phase ─────────────────────────────────────────────────
  // loading | splash | modeSelect | levelSelect | name | tutorial | app
  const [phase, setPhase] = useState("loading");

  // ── Navigation ───────────────────────────────────────────
  const [screen,       setScreen]       = useState("home");
  const [learningPath, setLearningPath] = useState(null);
  const [topic,        setTopic]        = useState(null);
  const [subtopic,     setSubtopic]     = useState(null);
  const [lessonOpen,   setLessonOpen]   = useState(false);
  const [practiceMode, setPracticeMode] = useState(false);
  const [showAdmin,    setShowAdmin]    = useState(false);

  // ── Profile (from Supabase) ───────────────────────────────
  const { profile, updateProfile, loading: profileLoading } = useProfile();

  // ── Progress ──────────────────────────────────────────────
  const [completedIds, setCompletedIds] = useState([]);

  // Load completed subtopic IDs from Supabase whenever auth user changes
  useEffect(() => {
    if (!authUser) { setCompletedIds([]); return; }
    let cancelled = false;
    supabase
      .from('user_progress')
      .select('subtopic_id')
      .eq('user_id', authUser.id)
      .eq('completed', true)
      .then(({ data }) => {
        if (!cancelled) setCompletedIds((data || []).map(r => r.subtopic_id));
      });
    return () => { cancelled = true; };
  }, [authUser]);

  // ── 1. Auth listener ──────────────────────────────────────
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setAuthUser(session?.user ?? null);
      setAuthReady(true);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (_event, session) => {
        setAuthUser(session?.user ?? null);
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  // ── 2. Decide phase once auth + profile are ready ─────────
  useEffect(() => {
    if (!authReady) return;

    if (!authUser) {
      setPhase("splash");
      return;
    }

    // Still waiting for profile to load from Supabase
    if (profileLoading) return;

    // Profile loaded — check completeness
    if (!profile) {
      // Profile row doesn't exist yet (shouldn't happen due to trigger, but safe)
      setPhase("name");
      return;
    }

    if (!profile.name) {
      setPhase("name");
      return;
    }

    if (!profile.grade || !profile.mode) {
      setPhase("levelSelect");
      return;
    }

    setPhase("app");
  }, [authReady, authUser, profile, profileLoading]);

  // ── 3. Resolve learning path when grade/mode changes ──────
  // This is the piece that was in the README — now correctly
  // placed inside the hook where profile is in scope.
  useEffect(() => {
    if (!profile?.grade || !profile?.mode) {
      setLearningPath(null);
      return;
    }

    let cancelled = false;

    supabase
      .from('learning_paths')
      .select('id, name, slug, mode, grade, has_curriculum, icon')
      .eq('grade', profile.grade)
      .eq('mode', profile.mode)
      .eq('is_active', true)
      .maybeSingle()
      .then(({ data }) => {
        if (!cancelled && data) setLearningPath(data);
      });

    return () => { cancelled = true; };
  }, [profile?.grade, profile?.mode]);

  // ── Navigation helpers ────────────────────────────────────
  const switchScreen = useCallback((s) => {
    setScreen(s);
    setTopic(null);
    setSubtopic(null);
    setLessonOpen(false);
    setPracticeMode(false);
  }, []);

  const selectTopic = useCallback((t) => {
    setTopic(t);
    setSubtopic(null);
    setLessonOpen(false);
  }, []);

  const selectSubtopic = useCallback((s) => {
    setSubtopic(s);
    setLessonOpen(true);
    setPracticeMode(false);
  }, []);

  const goBack = useCallback(() => {
    if (practiceMode) { setPracticeMode(false); return; }
    if (lessonOpen)   { setLessonOpen(false); setSubtopic(null); return; }
    if (subtopic)     { setSubtopic(null); return; }
    if (topic)        { setTopic(null); return; }
  }, [practiceMode, lessonOpen, subtopic, topic]);

  // ── Profile save helpers ──────────────────────────────────
  const handleSaveName = useCallback(async (name) => {
    await updateProfile({ name });
  }, [updateProfile]);

  const handleSaveClass = useCallback(async (grade) => {
    const examTypes = ['WAEC', 'JAMB', 'NECO', 'GCE', 'BECE', 'IGCSE'];
    const mode = examTypes.includes(grade) ? 'exam' : 'school';
    await updateProfile({ grade, mode });
    setTopic(null);
    setSubtopic(null);
    setLessonOpen(false);
    setLearningPath(null); // will re-resolve via the useEffect above
  }, [updateProfile]);

  const completeOnboarding = useCallback(async ({ name, grade }) => {
    const examTypes = ['WAEC', 'JAMB', 'NECO', 'GCE', 'BECE', 'IGCSE'];
    const mode = examTypes.includes(grade) ? 'exam' : 'school';
    await updateProfile({ name, grade, mode });
    setPhase("tutorial");
  }, [updateProfile]);

  return {
    // Auth
    authUser, authReady,
    // Phase
    phase, setPhase,
    // Profile
    profile,
    // Navigation
    screen, switchScreen,
    learningPath, setLearningPath,
    topic, selectTopic,
    subtopic, selectSubtopic,
    lessonOpen, setLessonOpen,
    practiceMode, setPracticeMode,
    showAdmin, setShowAdmin,
    goBack,
    // Progress
    completedIds, setCompletedIds,
    // Actions
    handleSaveName, handleSaveClass, completeOnboarding,
  };
}